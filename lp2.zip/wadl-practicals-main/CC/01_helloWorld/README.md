/home/pavi/Downloads/google-cloud-cli-431.0.0-linux-arm/google-cloud-sdk/bin/dev_appserver.py


python3 /home/pavi/Downloads/google-cloud-cli-431.0.0-linux-arm/google-cloud-sdk/bin/dev_appserver.py ./